import os


import asyncio
import zendriver as zd
from colorama import init, Fore, Style
import random
import string
import time
import re
import requests
import urllib.parse
import base64
import imaplib
import email as email_lib
from email.header import decode_header
from pystyle import Colorate, Colors, Center
import json
import sys
import zipfile
import io
from datetime import datetime

NOPECHA_KEY = "I-CX6GPNBR6YVA"
try:
    with open("input/config.json", "r") as _cf:
        _config = json.load(_cf)
        NOPECHA_KEY = _config.get("nopechaKey", "")
except:
    pass

init(autoreset=True)

def ts():
    now = datetime.now()
    return f"{now.hour:02d}:{now.minute:02d}:{now.second:02d}"

def log(message, log_type="info", thread_id=None):
    """Log with timestamp, colored tag, thread ID"""
    tags = {
        "success": (f"{Fore.GREEN}{Style.BRIGHT}COP{Style.RESET_ALL}", Fore.GREEN),
        "info":    (f"{Fore.CYAN}{Style.BRIGHT}INF{Style.RESET_ALL}", Fore.CYAN),
        "warning": (f"{Fore.YELLOW}{Style.BRIGHT}WAR{Style.RESET_ALL}", Fore.YELLOW),
        "error":   (f"{Fore.RED}{Style.BRIGHT}DBG{Style.RESET_ALL}", Fore.RED),
    }
    tag, color = tags.get(log_type, tags["info"])
    tid = f"  {Style.DIM}T{thread_id}{Style.RESET_ALL}" if thread_id is not None else ""
    print(f"{Style.DIM}{ts()}{Style.RESET_ALL}  {tag}{tid}  {Fore.WHITE}{message}{Style.RESET_ALL}")

os.system('cls' if os.name == 'nt' else 'clear')
print()
log("kanishk fucks uuu", "success")
print()


class MailOperations:
    def __init__(self):
        self.API_URL = "https://mail.boostcord.shop/api/v1"
        self.API_KEY = "BB4CF7-2ABBE0-63A739-2F8F19-738BDC"
        self.DOMAIN = "boostcord.shop"
        self.HEADERS = {"X-API-Key": self.API_KEY, "Content-Type": "application/json"}
        self.current_email = None
        self.current_password = None

    def _random_local(self):
        first = random.choice(["alex","john","michael","chris","daniel","ryan","kevin","james","robert","david",
            "matthew","anthony","joshua","andrew","joseph","mark","william","thomas","charles","brian",
            "jason","justin","eric","benjamin","samuel","patrick","scott","steven","paul","adam",
            "nathan","jonathan","dylan","aaron","tyler","brandon","cameron","sean","logan","ethan"])
        last = random.choice(["smith","johnson","brown","taylor","anderson","thomas","jackson","white","harris",
            "martin","thompson","garcia","martinez","robinson","clark","lewis","lee","walker","hall",
            "allen","young","king","wright","scott","torres","nguyen","hill","flores","green"])
        return f"{first}.{last}{random.randint(10, 999)}"

    def _random_password(self, length=12):
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#"
        return "".join(random.choice(chars) for _ in range(length))

    def generate_email(self, tid=""):
        try:
            local_part = self._random_local()
            password = self._random_password()
            email = f"{local_part}@{self.DOMAIN}"
            payload = {
                "local_part": local_part, "domain": self.DOMAIN,
                "password": password, "password2": password,
                "quota": 256, "name": f"meowwW ghop ghop", "active": 1
            }
            response = requests.post(f"{self.API_URL}/add/mailbox", headers=self.HEADERS, json=payload, timeout=15)
            if response.status_code == 200:
                self.current_email = email
                self.current_password = password
                log(f"Mailbox Created | {email}", "success", tid)
                return email
            else:
                log(f"Mailbox Failed | {response.status_code}", "error", tid)
                return None
        except Exception as e:
            log(f"Mailbox Error | {e}", "error", tid)
            return None

    def fetch_inbox(self):
        if not self.current_email or not self.current_password:
            return []
        try:
            mail = imaplib.IMAP4_SSL("mail.boostcord.shop", 993)
            mail.login(self.current_email, self.current_password)
            mail.select("INBOX")
            status, messages = mail.search(None, "ALL")
            if status != "OK" or not messages[0].split():
                mail.logout()
                return []
            results = []
            for eid in messages[0].split():
                status, msg_data = mail.fetch(eid, "(RFC822)")
                if status != "OK":
                    continue
                msg = email_lib.message_from_bytes(msg_data[0][1])
                html_content, text_content = "", ""
                if msg.is_multipart():
                    for part in msg.walk():
                        try:
                            body = part.get_payload(decode=True)
                            if body:
                                decoded = body.decode(part.get_content_charset() or 'utf-8', errors='replace')
                                if part.get_content_type() == "text/html":
                                    html_content += decoded
                                elif part.get_content_type() == "text/plain":
                                    text_content += decoded
                        except:
                            continue
                else:
                    try:
                        body = msg.get_payload(decode=True)
                        if body:
                            decoded = body.decode(msg.get_content_charset() or 'utf-8', errors='replace')
                            if msg.get_content_type() == "text/html":
                                html_content = decoded
                            else:
                                text_content = decoded
                    except:
                        pass
                results.append({"html": html_content, "text": text_content})
            mail.logout()
            return results
        except:
            return []


def get_proxy():
    try:
        with open("proxies.txt", "r") as f:
            proxies = [l.strip() for l in f if l.strip()]
        return random.choice(proxies) if proxies else None
    except:
        return None

def parse_proxy(proxy_str):
    """Parse proxy in multiple formats:
    - host:port:user:pass
    - http://user:pass@host:port
    - host:port
    """
    proxy_str = proxy_str.strip()
    
    m = re.match(r"http[s]?://(?P<user>[^:]+):(?P<pass>[^@]+)@(?P<host>[^:]+):(?P<port>\d+)", proxy_str)
    if m:
        return {"host": m.group("host"), "port": m.group("port"), "user": m.group("user"), "pass": m.group("pass")}
    
    parts = proxy_str.split(":")
    if len(parts) == 4:
        return {"host": parts[0], "port": parts[1], "user": parts[2], "pass": parts[3]}
    
    if len(parts) == 2:
        return {"host": parts[0], "port": parts[1], "user": None, "pass": None}
    
    return None


def extract_otp(emails_data):
    """Extract 6-digit OTP from email content"""
    ignore = ["595959"]
    for doc in emails_data:
        html = doc.get('html', '')
        text = doc.get('text', '')
        for pattern in [r'>\s*(\d{6})\s*<', r'\b(\d{6})\b']:
            for match in re.finditer(pattern, html + ' ' + text):
                otp = match.group(1).strip()
                if len(otp) == 6 and otp.isdigit() and otp not in ignore:
                    return otp
    return None


def ensure_nopecha():
    ext_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nopecha_extension")
    if not os.path.exists(os.path.join(ext_path, "manifest.json")):
        log("Downloading NopeCHA extension...", "info")
        try:
            resp = requests.get("https://github.com/NopeCHALLC/nopecha-extension/releases/latest/download/chromium.zip", timeout=30)
            if resp.status_code == 200:
                z = zipfile.ZipFile(io.BytesIO(resp.content))
                z.extractall(ext_path)
                log("NopeCHA extension ready", "success")
        except Exception as e:
            log(f"NopeCHA download failed | {e}", "error")
    
    if NOPECHA_KEY and os.path.exists(os.path.join(ext_path, "background.js")):
        bg_path = os.path.join(ext_path, "background.js")
        try:
            with open(bg_path, "r", encoding="utf-8") as f:
                bg_content = f.read()
            
            inject_marker = f'/*NOPECHA_KEY_INJECT*/'
            if inject_marker not in bg_content:
                key_inject = f'''{inject_marker}
chrome.storage.local.set({{
    "key": "{NOPECHA_KEY}",
    "enabled": true,
    "hcaptcha_auto_open": true,
    "hcaptcha_auto_solve": true,
    "recaptcha_auto_open": true,
    "recaptcha_auto_solve": true,
    "funcaptcha_auto_open": true,
    "funcaptcha_auto_solve": true,
    "turnstile_auto_solve": true,
    "awscaptcha_auto_solve": true
}});
'''
                with open(bg_path, "w", encoding="utf-8") as f:
                    f.write(key_inject + bg_content)
                log("NopeCHA key injected", "success")
        except Exception as e:
            log(f"NopeCHA key inject failed | {e}", "warning")
    
    return ext_path



async def run_thread(thread_id, use_proxy=False):
    """Single thread that creates account, solves captcha, clicks Get, saves to success.txt"""
    tid = thread_id
    start_time = time.time()
    log("Starting...", "info", tid)
    
    mailopss = MailOperations()
    email = mailopss.generate_email(tid)
    if not email:
        return False
    password = mailopss.current_password
    
    nopecha_path = ensure_nopecha()
    
    browser_args = []
    proxy_user = None
    proxy_pass = None
    
    if use_proxy:
        proxy = get_proxy()
        if proxy:
            proxy_data = parse_proxy(proxy)
            if proxy_data:
                browser_args.append(f"--proxy-server=http://{proxy_data['host']}:{proxy_data['port']}")
                log(f"Using proxy: {proxy_data['host']}:{proxy_data['port']}", "info", tid)
                if proxy_data.get('user') and proxy_data.get('pass'):
                    proxy_user = proxy_data['user']
                    proxy_pass = proxy_data['pass']
    
    proxy_ext_path = None
    if proxy_user and proxy_pass:
        proxy_ext_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "proxy_auth_ext")
        os.makedirs(proxy_ext_path, exist_ok=True)
        with open(os.path.join(proxy_ext_path, "manifest.json"), "w") as f:
            json.dump({
                "version": "1.0.0",
                "manifest_version": 2,
                "name": "Proxy Auth Helper",
                "permissions": ["proxy", "tabs", "unlimitedStorage", "storage", "<all_urls>", "webRequest", "webRequestBlocking"],
                "background": {"scripts": ["background.js"]},
                "minimum_chrome_version": "22.0.0"
            }, f)
        with open(os.path.join(proxy_ext_path, "background.js"), "w") as f:
            f.write(f'''chrome.webRequest.onAuthRequired.addListener(function(details) {{
  return {{ authCredentials: {{ username: "{proxy_user}", password: "{proxy_pass}" }} }};
}}, {{urls: ["<all_urls>"]}}, ["blocking"]);''')
    
    ext_paths = []
    if os.path.exists(os.path.join(nopecha_path, "manifest.json")):
        ext_paths.append(nopecha_path)
    if proxy_ext_path:
        ext_paths.append(proxy_ext_path)
    
    if ext_paths:
        browser_args.append(f"--load-extension={','.join(ext_paths)}")
    
    import tempfile
    user_data_dir = os.path.join(tempfile.gettempdir(), f"epic_chrome_t{tid}_{int(time.time())}")
    browser_args.append(f"--user-data-dir={user_data_dir}")
    
    browser = None
    try:
        browser = await zd.start(browser_args=browser_args, browser_executable_path=r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
        
        if NOPECHA_KEY:
            try:
                await browser.get(f"https://nopecha.com/setup#{NOPECHA_KEY}")
                await asyncio.sleep(5)
                log("NopeCHA Configured", "success", tid)
            except:
                pass
        
        page = await browser.get("https://www.epicgames.com/id/register/date-of-birth?lang=en-US&redirect_uri=https%3A%2F%2Fstore.epicgames.com%2Fen-US%2Fp%2Fdiscord--discord-nitro&client_id=875a3b57d3a640a6b7f9b4e883463ab4")
        await page.wait_for_ready_state('complete', timeout=15000)
        await page.evaluate('document.body.style.zoom = "60%"')
        log("Opening Registration...", "info", tid)
        
        for _ in range(10):
            month = await page.query_selector('#month')
            if month:
                break
            await asyncio.sleep(1)
        
        dob_done = False
        for retry in range(3):
            try:
                month = await page.query_selector('#month')
                if not month:
                    await asyncio.sleep(2)
                    month = await page.query_selector('#month')
                
                if month:
                    await month.mouse_click("left")
                    await asyncio.sleep(1)
                    
                    jan_clicked = False
                    for el in await page.query_selector_all('li, span, div[role="option"]'):
                        try:
                            if el.text and el.text.strip().lower() == "january":
                                await el.mouse_click("left")
                                jan_clicked = True
                                break
                        except:
                            continue
                    
                    if not jan_clicked:
                        await page.evaluate('''() => {
                            const items = document.querySelectorAll('li, [role="option"]');
                            for (let item of items) {
                                if (item.textContent.trim().toLowerCase() === 'january') {
                                    item.click(); return;
                                }
                            }
                        }''')
                    
                    await asyncio.sleep(0.5)
                
                day = await page.query_selector('#day')
                if day:
                    await day.mouse_click("left")
                    await asyncio.sleep(0.2)
                    await day.send_keys("1")
                
                await asyncio.sleep(0.3)
                
                year = await page.query_selector('#year')
                if year:
                    await year.mouse_click("left")
                    await asyncio.sleep(0.2)
                    await year.send_keys("1999")
                
                await asyncio.sleep(0.5)
                
                clicked_continue = False
                for btn in await page.query_selector_all('button'):
                    if btn.text and "continue" in btn.text.lower():
                        await btn.mouse_click("left")
                        clicked_continue = True
                        break
                
                if not clicked_continue:
                    await page.evaluate('''() => {
                        const btns = document.querySelectorAll('button');
                        for (let btn of btns) {
                            if (btn.textContent.toLowerCase().includes('continue')) { btn.click(); return; }
                        }
                    }''')
                
                await asyncio.sleep(2)
                try:
                    still_on_dob = await page.query_selector('#month')
                    if still_on_dob:
                        log(f"DOB not accepted, retrying ({retry+1}/3)", "warning", tid)
                        continue
                except:
                    pass
                
                dob_done = True
                log(f"DOB Submitted ({retry+1}/3)", "info", tid)
                break
            except Exception as e:
                log(f"DOB Failed ({retry+1}/3) | {e}", "warning", tid)
                await asyncio.sleep(2)
        
        if not dob_done:
            log("DOB Failed after 3 retries", "error", tid)
            return False
        
        await asyncio.sleep(2)
        
        email_done = False
        for retry in range(3):
            try:
                email_input = await page.query_selector('input[type="email"], #email')
                if email_input:
                    await email_input.mouse_click("left")
                    await asyncio.sleep(0.1)
                    await email_input.send_keys(email)
                
                await asyncio.sleep(0.5)
                for btn in await page.query_selector_all('button'):
                    if btn.text and "continue" in btn.text.lower():
                        await btn.mouse_click("left")
                        break
                
                email_done = True
                log(f"Email Submitted ({retry+1}/3)", "info", tid)
                break
            except Exception as e:
                log(f"Email Failed ({retry+1}/3) | {e}", "warning", tid)
                await asyncio.sleep(2)
        
        if not email_done:
            log("Email Failed after 3 retries", "error", tid)
            return False
        
        await asyncio.sleep(2)
        
        async def fill(selector, value):
            el = await page.query_selector(selector)
            if el:
                await el.mouse_click("left")
                await asyncio.sleep(0.1)
                await el.send_keys(value)
                return True
            return False
        
        form_done = False
        for retry in range(3):
            try:
                await fill('#name', 'meowwW')
                await asyncio.sleep(0.2)
                await fill('#lastName', 'ghop ghop')
                await asyncio.sleep(0.2)
                
                pw = random.choice(string.ascii_uppercase) + random.choice(string.ascii_lowercase) + random.choice(string.digits) + random.choice("!@#$") + ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(6))
                pw = ''.join(random.sample(pw, len(pw)))  # shuffle
                await fill('#password', pw)
                await asyncio.sleep(0.2)
                
                dn = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(16))
                await fill('#displayName', dn)
                await asyncio.sleep(0.2)
                
                tos = await page.query_selector('#tos')
                if tos:
                    await tos.mouse_click("left")
                else:
                    await page.evaluate('() => { document.querySelectorAll("input[type=checkbox]").forEach(c => { if(!c.checked) c.click(); }); }')
                
                await asyncio.sleep(0.3)
                
                for btn in await page.query_selector_all('button'):
                    if btn.text and "continue" in btn.text.lower():
                        await btn.mouse_click("left")
                        break
                
                form_done = True
                log(f"Details Submitted ({retry+1}/3)", "info", tid)
                break
            except Exception as e:
                log(f"Form Failed ({retry+1}/3) | {e}", "warning", tid)
                await asyncio.sleep(2)
        
        if not form_done:
            log("Form Failed after 3 retries", "error", tid)
            return False
        
        otp_entered = False
        captcha_logged = False
        
        await asyncio.sleep(3)
        
        for attempt in range(90):
            otp_field = None
            for sel in ['input[inputmode="numeric"]', 'input[type="tel"]', 'input[name*="code"]']:
                otp_field = await page.query_selector(sel)
                if otp_field:
                    break
            
            if otp_field:
                log("OTP Page Ready", "success", tid)
                log("Fetching OTP via IMAP...", "info", tid)
                
                otp = None
                for otp_retry in range(3):  # 3 retries on OTP fetching
                    for otp_attempt in range(20):
                        try:
                            emails_data = mailopss.fetch_inbox()
                            if emails_data:
                                otp = extract_otp(emails_data)
                                if otp:
                                    break
                                else:
                                    log(f"Waiting for OTP... ({otp_attempt*3}s) | {len(emails_data)} emails, no OTP yet", "info", tid)
                        except Exception as e:
                            log(f"IMAP error: {e}", "warning", tid)
                        await asyncio.sleep(3)
                    
                    if otp:
                        break
                    log(f"OTP Fetch Retry ({otp_retry+1}/3)", "warning", tid)
                    await asyncio.sleep(5)
                
                if otp:
                    log(f"OTP Received | {otp}", "success", tid)
                    
                    for otp_enter_retry in range(3):
                        try:
                            boxes = await page.query_selector_all('input[type="tel"], input[inputmode="numeric"]')
                            if len(boxes) >= 6:
                                for i, digit in enumerate(otp[:6]):
                                    if i < len(boxes):
                                        await boxes[i].mouse_click("left")
                                        await boxes[i].send_keys(digit)
                                        await asyncio.sleep(0.05)
                            elif boxes:
                                await boxes[0].mouse_click("left")
                                await boxes[0].send_keys(otp)
                            
                            await asyncio.sleep(1)
                            for btn in await page.query_selector_all('button'):
                                txt = btn.text.lower() if btn.text else ""
                                if "continue" in txt or "verify" in txt:
                                    await btn.mouse_click("left")
                                    break
                            
                            otp_entered = True
                            log(f"OTP Entered ({otp_enter_retry+1}/3)", "success", tid)
                            break
                        except Exception as e:
                            log(f"OTP Entry Failed ({otp_enter_retry+1}/3) | {e}", "warning", tid)
                            await asyncio.sleep(2)
                else:
                    log("OTP Timeout | No email received (3/3)", "error", tid)
                break
            else:
                if not captcha_logged:
                    captcha = await page.query_selector('iframe[src*="arkoselabs"], iframe[src*="funcaptcha"]')
                    if captcha:
                        log("Captcha Detected... | Solving...", "warning", tid)
                        captcha_logged = True
            
            await asyncio.sleep(2)
        
        if not otp_entered:
            log("Failed | No OTP page after timeout (3/3)", "error", tid)
            return False
        
        await asyncio.sleep(5)
        for retry in range(3):
            try:
                for btn in await page.query_selector_all('button'):
                    if btn.text and "accept" in btn.text.lower():
                        await btn.mouse_click("left")
                        log(f"EULA Accepted ({retry+1}/3)", "success", tid)
                        break
                break
            except:
                await asyncio.sleep(2)
        
        log("Claiming Nitro...", "info", tid)
        get_clicked = False
        
        while not get_clicked:
            for retry in range(3):
                try:
                    for btn in await page.query_selector_all('button'):
                        txt = (btn.text or "").strip().lower()
                        if txt in ["get", "place order", "order now", "purchase"]:
                            await btn.mouse_click("left")
                            log(f"Clicked '{txt.title()}' ({retry+1}/3)", "success", tid)
                            get_clicked = True
                            break
                    
                    if not get_clicked:
                        result = await page.evaluate('''() => {
                            for (let btn of document.querySelectorAll('button')) {
                                const t = (btn.textContent||'').trim().toLowerCase();
                                if (['get','place order','order now','purchase'].includes(t) && !btn.disabled) {
                                    btn.click(); return t;
                                }
                            }
                            return null;
                        }''')
                        if result:
                            log(f"Clicked '{result.title()}' ({retry+1}/3)", "success", tid)
                            get_clicked = True
                    
                    if get_clicked:
                        break
                except:
                    pass
                await asyncio.sleep(1)
            
            if not get_clicked:
                await asyncio.sleep(2)
        
        await asyncio.sleep(10)
        elapsed = round(time.time() - start_time, 1)
        with open("success.txt", "a") as f:
            f.write(f"{email}:{password}\n")
        log(f"Purchase Success | {email} {elapsed}s", "success", tid)
        log(f"Saved to success.txt", "success", tid)
        
        await asyncio.sleep(15)
        return True
        
    except Exception as e:
        log(f"Error | {e}", "error", tid)
        return False
    finally:
        if browser:
            try:
                await browser.stop()
            except:
                pass
        try:
            import shutil
            if user_data_dir and os.path.exists(user_data_dir):
                shutil.rmtree(user_data_dir, ignore_errors=True)
        except:
            pass


def rotate_ip():
    """Try to rotate IP via Surfshark using PowerShell UI Automation"""
    import subprocess
    log("Rotating IP...", "info")
    try:
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "click_surfshark.ps1")
        if os.path.exists(script_path):
            subprocess.run(['powershell', '-ExecutionPolicy', 'Bypass', '-File', script_path],
                          capture_output=True, timeout=15)
            time.sleep(5)
            subprocess.run(['powershell', '-ExecutionPolicy', 'Bypass', '-File', script_path],
                          capture_output=True, timeout=15)
            time.sleep(15)
        
        try:
            resp = requests.get("https://api.ipify.org", timeout=10)
            log(f"Current IP: {resp.text}", "success")
        except:
            log("IP check failed", "warning")
    except Exception as e:
        log(f"IP Rotation Error | {e}", "error")


def wait_for_vpn():
    """Check VPN status and try to connect"""
    import subprocess
    log("Checking VPN...", "info")
    
    try:
        resp = requests.get("https://api.ipify.org", timeout=10)
        log(f"Current IP: {resp.text}", "info")
    except:
        pass
    
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "click_surfshark.ps1")
    if os.path.exists(script_path):
        try:
            result = subprocess.run(['powershell', '-ExecutionPolicy', 'Bypass', '-File', script_path],
                                    capture_output=True, text=True, timeout=15)
            if "CLICKED" in result.stdout:
                log("Surfshark connect triggered", "info")
                time.sleep(15)
                try:
                    resp = requests.get("https://api.ipify.org", timeout=10)
                    log(f"IP after connect: {resp.text}", "success")
                except:
                    pass
        except:
            pass
    
    return True


async def main():
    print(f"{Style.DIM}Mode:{Style.RESET_ALL}")
    print(f"  {Fore.CYAN}1{Style.RESET_ALL} - Proxy (from proxies.txt)")
    print(f"  {Fore.CYAN}2{Style.RESET_ALL} - VPN (Surfshark)")
    print(f"  {Fore.CYAN}3{Style.RESET_ALL} - Normal IP (no proxy/vpn)")
    try:
        mode = int(input(f"{Style.DIM}Choose (1/2/3):{Style.RESET_ALL} "))
    except:
        mode = 3
    
    use_proxy = (mode == 1)
    use_vpn = (mode == 2)
    
    try:
        threads = int(input(f"{Style.DIM}Threads:{Style.RESET_ALL} "))
        threads = max(1, threads)
    except:
        threads = 1
    
    accounts_per_ip = 4
    
    if use_proxy:
        try:
            with open("proxies.txt", "r") as f:
                proxy_list = [l.strip() for l in f if l.strip()]
            log(f"Proxy Mode | {len(proxy_list)} proxies loaded", "success")
        except:
            log("proxies.txt not found or empty!", "error")
            return
        log(f"Starting {threads} thread(s) | Proxy mode", "info")
    elif use_vpn:
        log(f"Starting {threads} thread(s) | VPN mode | {accounts_per_ip} accounts per IP", "info")
        wait_for_vpn()
    else:
        log(f"Starting {threads} thread(s) | Normal IP mode", "info")
    
    print()
    
    batch = 1
    while True:
        if use_vpn and batch > 1:
            rotate_ip()
        
        tasks = [run_thread(i + 1, use_proxy=use_proxy) for i in range(threads)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        success = sum(1 for r in results if r is True)
        failed = sum(1 for r in results if r is not True)
        log(f"Batch #{batch} complete | Success: {success} | Failed: {failed}", "success")
        
        batch += 1
        if use_vpn:
            log("Rotating IP for next batch...", "info")
        await asyncio.sleep(3)
        print()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Style.DIM}Stopped.{Style.RESET_ALL}")
